package com.reserva;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by Usuario on 15/03/2017.
 */

public class ActividadExtra extends Activity {
    //variables
    TextView muestraDatos;
    String nombre = "";
    Button si1, no1, Enviar;
    String resp1="", resp2="";
    EditText comentario;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actividadextra);

        muestraDatos = (TextView) findViewById(R.id.muestraInfo);
        Bundle enviarDatos = new Bundle();
        enviarDatos = this.getIntent().getExtras();
        nombre = enviarDatos.getString("nombre");
        muestraDatos.setText("Hola" + nombre);
        comentario = (EditText) findViewById(R.id.comentario);

    }

    protected void onClick(View v){
        if(v == si1) {
            resp1 = "Si";
        }else{
            if(v == no1) {
                resp1 = "No";
            }
        }

       if(v == Enviar){
           resp2 = comentario.getText().toString();
       }


    }


    public void reserva(View v) {
        Intent envia = new Intent(this,MainActivity.class);
        Bundle Encuesta = new Bundle();
        Encuesta.putString("nombre", nombre);
        Encuesta.putString("resp1", resp1);
        Encuesta.putString("resp2", resp2);
        envia.putExtras(Encuesta);
        finish();
        startActivity(envia);
    }
            }
